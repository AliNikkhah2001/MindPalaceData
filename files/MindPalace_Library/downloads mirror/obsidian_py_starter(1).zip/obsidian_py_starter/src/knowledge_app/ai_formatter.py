from __future__ import annotations

from dataclasses import dataclass
import difflib
import re


PROTECTED_PATTERNS = {
    "wikilinks": re.compile(r"\[\[[^\]]+\]\]"),
    "embeds": re.compile(r"!\[\[[^\]]+\]\]"),
    "urls": re.compile(r"https?://[^\s)]+"),
}


@dataclass(slots=True)
class FormatProposal:
    original: str
    proposed: str
    diff: str
    safe: bool
    reasons: list[str]


def _protected_values(text: str) -> dict[str, list[str]]:
    return {
        name: sorted(pattern.findall(text))
        for name, pattern in PROTECTED_PATTERNS.items()
    }


def validate_proposal(original: str, proposed: str) -> tuple[bool, list[str]]:
    reasons: list[str] = []
    before = _protected_values(original)
    after = _protected_values(proposed)

    for key in before:
        if before[key] != after[key]:
            reasons.append(f"Protected construct changed: {key}")

    return (not reasons), reasons


def make_proposal(original: str, proposed: str) -> FormatProposal:
    safe, reasons = validate_proposal(original, proposed)
    diff = "".join(
        difflib.unified_diff(
            original.splitlines(keepends=True),
            proposed.splitlines(keepends=True),
            fromfile="before.md",
            tofile="after.md",
        )
    )
    return FormatProposal(
        original=original,
        proposed=proposed,
        diff=diff,
        safe=safe,
        reasons=reasons,
    )


def formatter_contract() -> str:
    return """You format Markdown without changing factual meaning.

Hard constraints:
- Preserve every [[wikilink]] exactly.
- Preserve embeds, URLs, code fences, citations, and YAML values.
- Do not invent facts, links, tags, or citations.
- Improve only headings, lists, whitespace, paragraph structure, and readability.
- Return only the transformed Markdown.
"""

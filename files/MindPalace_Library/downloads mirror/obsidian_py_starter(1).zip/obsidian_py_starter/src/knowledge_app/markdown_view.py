from __future__ import annotations

from markdown_it import MarkdownIt
from mdit_py_plugins.front_matter import front_matter_plugin

# Keep raw HTML disabled in preview by default.
MD = (
    MarkdownIt("commonmark", {"html": False, "linkify": True, "typographer": False})
    .use(front_matter_plugin)
    .enable("table")
)


def render_markdown(text: str) -> str:
    # Minimal wikilink rendering for preview.
    # A production version should implement this as a parser extension.
    import re

    converted = re.sub(
        r"(?<!!)\[\[([^\]|#]+)(?:#[^\]|]+)?(?:\|([^\]]+))?\]\]",
        lambda m: f"[{m.group(2) or m.group(1)}](note://{m.group(1).strip()})",
        text,
    )
    return MD.render(converted)

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass(slots=True)
class Note:
    path: Path
    title: str
    text: str
    links: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)

    @property
    def key(self) -> str:
        return self.path.stem

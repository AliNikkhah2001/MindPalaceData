from __future__ import annotations

from collections import defaultdict
from pathlib import Path

import networkx as nx

from .models import Note
from .vault import scan_vault


class VaultIndex:
    def __init__(self, root: Path):
        self.root = root
        self.notes: dict[str, Note] = {}
        self.backlinks: dict[str, set[str]] = defaultdict(set)
        self.graph = nx.DiGraph()

    def rebuild(self) -> None:
        notes = scan_vault(self.root)
        self.notes = {note.key: note for note in notes}
        self.backlinks.clear()
        self.graph.clear()

        for note in notes:
            self.graph.add_node(
                note.key,
                label=note.title,
                path=str(note.path),
                tags=note.tags,
            )

        for note in notes:
            for target in note.links:
                target_key = Path(target).stem
                # Keep unresolved links visible in the graph.
                if target_key not in self.graph:
                    self.graph.add_node(
                        target_key,
                        label=target_key,
                        unresolved=True,
                    )
                self.graph.add_edge(note.key, target_key)
                self.backlinks[target_key].add(note.key)

    def get_backlinks(self, note_key: str) -> list[str]:
        return sorted(self.backlinks.get(note_key, set()))

    def search_titles(self, query: str) -> list[Note]:
        q = query.casefold().strip()
        if not q:
            return list(self.notes.values())
        return [
            note for note in self.notes.values()
            if q in note.title.casefold() or q in note.text.casefold()
        ]

from __future__ import annotations

import tempfile
from pathlib import Path

import networkx as nx
from PySide6.QtCore import QUrl
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWidgets import QDialog, QVBoxLayout
from pyvis.network import Network


class GraphDialog(QDialog):
    def __init__(self, graph: nx.DiGraph, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Knowledge Graph")
        self.resize(1100, 800)

        view = QWebEngineView(self)
        layout = QVBoxLayout(self)
        layout.addWidget(view)

        net = Network(
            height="100%",
            width="100%",
            directed=True,
            cdn_resources="in_line",
            notebook=False,
        )
        net.from_nx(graph)
        net.toggle_physics(True)

        html = net.generate_html()
        temp_path = Path(tempfile.gettempdir()) / "knowledge_graph.html"
        temp_path.write_text(html, encoding="utf-8")
        view.load(QUrl.fromLocalFile(str(temp_path)))

from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QKeySequence
from PySide6.QtWidgets import (
    QApplication,
    QFileSystemModel,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QSplitter,
    QTreeView,
    QVBoxLayout,
    QWidget,
)
from PySide6.QtWebEngineWidgets import QWebEngineView

from .graph_view import GraphDialog
from .index import VaultIndex
from .markdown_view import render_markdown


class MainWindow(QMainWindow):
    def __init__(self, vault_root: Path):
        super().__init__()
        self.vault_root = vault_root.resolve()
        self.index = VaultIndex(self.vault_root)
        self.index.rebuild()
        self.current_path: Path | None = None

        self.setWindowTitle("Python Knowledge Graph Starter")
        self.resize(1400, 900)

        self.tree = QTreeView()
        self.fs_model = QFileSystemModel(self)
        self.fs_model.setRootPath(str(self.vault_root))
        self.fs_model.setNameFilters(["*.md"])
        self.fs_model.setNameFilterDisables(False)
        self.tree.setModel(self.fs_model)
        self.tree.setRootIndex(self.fs_model.index(str(self.vault_root)))
        self.tree.doubleClicked.connect(self._open_from_tree)

        self.editor = QPlainTextEdit()
        self.editor.setTabStopDistance(28)
        self.editor.textChanged.connect(self._refresh_preview)

        self.preview = QWebEngineView()

        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(self.tree)
        splitter.addWidget(self.editor)
        splitter.addWidget(self.preview)
        splitter.setSizes([260, 650, 490])
        self.setCentralWidget(splitter)

        self._build_actions()

    def _build_actions(self) -> None:
        save_action = QAction("Save", self)
        save_action.setShortcut(QKeySequence.Save)
        save_action.triggered.connect(self.save_current)
        self.addAction(save_action)

        graph_action = QAction("Graph", self)
        graph_action.setShortcut("Ctrl+G")
        graph_action.triggered.connect(self.show_graph)
        self.addAction(graph_action)
        self.menuBar().addAction(graph_action)

        rebuild_action = QAction("Rebuild Index", self)
        rebuild_action.triggered.connect(self.rebuild_index)
        self.menuBar().addAction(rebuild_action)

    def _open_from_tree(self, index) -> None:
        path = Path(self.fs_model.filePath(index))
        if path.suffix.lower() != ".md":
            return
        self.open_note(path)

    def open_note(self, path: Path) -> None:
        self.current_path = path
        text = path.read_text(encoding="utf-8")
        self.editor.blockSignals(True)
        self.editor.setPlainText(text)
        self.editor.blockSignals(False)
        self._refresh_preview()
        self.statusBar().showMessage(str(path))

    def _refresh_preview(self) -> None:
        html = render_markdown(self.editor.toPlainText())
        self.preview.setHtml(
            f"""
            <html>
              <head>
                <style>
                  body {{ max-width: 850px; margin: 32px auto; padding: 0 20px;
                         font-family: system-ui, sans-serif; line-height: 1.55; }}
                  code, pre {{ font-family: ui-monospace, monospace; }}
                  pre {{ padding: 12px; overflow-x: auto; background: rgba(127,127,127,.12); }}
                  blockquote {{ border-left: 3px solid #888; padding-left: 12px; }}
                </style>
              </head>
              <body>{html}</body>
            </html>
            """
        )

    def save_current(self) -> None:
        if not self.current_path:
            return
        self.current_path.write_text(self.editor.toPlainText(), encoding="utf-8")
        self.index.rebuild()
        self.statusBar().showMessage(f"Saved {self.current_path.name}", 2500)

    def rebuild_index(self) -> None:
        self.index.rebuild()
        self.statusBar().showMessage(
            f"Indexed {len(self.index.notes)} notes / "
            f"{self.index.graph.number_of_edges()} links",
            3000,
        )

    def show_graph(self) -> None:
        self.index.rebuild()
        dialog = GraphDialog(self.index.graph, self)
        dialog.exec()


def main() -> None:
    app = QApplication(sys.argv)
    vault = Path.cwd() / "vault"
    if not vault.exists():
        QMessageBox.critical(
            None,
            "Vault missing",
            f"Expected a vault directory at: {vault}",
        )
        raise SystemExit(1)

    window = MainWindow(vault)
    window.show()
    raise SystemExit(app.exec())


if __name__ == "__main__":
    main()

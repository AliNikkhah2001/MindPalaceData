from __future__ import annotations

import re
from pathlib import Path

import yaml

from .models import Note

WIKILINK_RE = re.compile(r"(?<!!)\[\[([^\]|#]+)(?:#[^\]|]+)?(?:\|[^\]]+)?\]\]")
TAG_RE = re.compile(r"(?<!\w)#([A-Za-z0-9_/-]+)")
FRONTMATTER_RE = re.compile(r"\A---\s*\n(.*?)\n---\s*(?:\n|$)", re.DOTALL)


def parse_note(path: Path) -> Note:
    text = path.read_text(encoding="utf-8")
    title = path.stem

    tags: set[str] = set(TAG_RE.findall(text))

    fm = FRONTMATTER_RE.match(text)
    if fm:
        try:
            data = yaml.safe_load(fm.group(1)) or {}
            raw_tags = data.get("tags", [])
            if isinstance(raw_tags, str):
                raw_tags = [raw_tags]
            tags.update(str(tag).lstrip("#") for tag in raw_tags)
            title = str(data.get("title", title))
        except yaml.YAMLError:
            pass

    links = [target.strip() for target in WIKILINK_RE.findall(text)]

    return Note(
        path=path,
        title=title,
        text=text,
        links=links,
        tags=sorted(tags),
    )


def scan_vault(root: Path) -> list[Note]:
    return [parse_note(p) for p in sorted(root.rglob("*.md"))]

---
tags:
  - demo
  - knowledge
---

# Welcome

This is a tiny local-first Markdown vault.

Open [[Graph Architecture]] and [[AI Formatter]].

## Idea

The filesystem is the source of truth. The application builds indexes over it.

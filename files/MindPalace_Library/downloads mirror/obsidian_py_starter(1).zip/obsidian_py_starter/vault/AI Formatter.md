# AI Formatter

A safe formatter should:

- preserve meaning
- preserve links
- preserve frontmatter
- return a patch or proposed replacement
- validate the result
- show a diff
- require approval before overwriting the canonical note

See [[Graph Architecture]].

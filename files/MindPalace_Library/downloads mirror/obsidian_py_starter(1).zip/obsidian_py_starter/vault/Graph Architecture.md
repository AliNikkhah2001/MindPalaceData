# Graph Architecture

Each Markdown file is a node.

A `[[wikilink]]` creates a directed edge to another note.

Backlinks are simply the reverse index of those edges.

See [[Welcome]] and [[AI Formatter]].

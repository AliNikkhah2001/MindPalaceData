# Obsidian-like Python starter

A deliberately small, local-first Markdown knowledge app baseline.

## What it has
- A vault made of ordinary `.md` files
- File tree
- Markdown editor
- HTML preview
- `[[wikilink]]` extraction
- Backlink/forward-link graph model
- Interactive graph window via PyVis
- A clean place to add AI formatting later

## Run

```bash
python -m venv .venv
# activate the environment
pip install -e .
knowledge-app
```

The demo vault is `./vault`.

## Important architecture note

The included `QPlainTextEdit` is a bootstrap editor so the project runs with only Python dependencies.
For a polished Obsidian-class editor, replace `MarkdownEditor` with a `QWebEngineView`
hosting CodeMirror 6 and bridge it to Python with Qt WebChannel.

Likewise, PyVis is excellent for the first graph MVP. For a production graph view,
replace it with Cytoscape.js (feature-rich) or Sigma.js (large WebGL graphs).

## Suggested next steps
1. Add a filesystem watcher and incremental index updates.
2. Store parsed note metadata in SQLite.
3. Add SQLite FTS search.
4. Resolve aliases and YAML frontmatter.
5. Add local graph / global graph modes.
6. Replace editor with CodeMirror 6.
7. Replace PyVis graph with Cytoscape.js or Sigma.js.
8. Add an AI formatter that produces a diff/patch, never an unconditional overwrite.
